#ifndef TestLED
#define TestLED

// library interface description
class TestLED
{
  public:
    TestLED(int);
    void turnOnOffLED(void);
};

#endif

